<?php
require_once __DIR__.'/includes/bootstrap.php';
header('X-Frame-Options: DENY');
try { $count=(int)db()->query('SELECT COUNT(*) FROM admin_users')->fetchColumn(); }
catch(Throwable $e) { http_response_code(503); exit('Database not configured.'); }
if($count>0){http_response_code(404);exit('Setup is closed.');}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $secret=(string)($_POST['setup_secret']??'');$user=trim((string)($_POST['username']??''));$pass=(string)($_POST['password']??'');
 if(!cfg('admin_setup_secret')||strlen((string)cfg('admin_setup_secret'))<32||!hash_equals((string)cfg('admin_setup_secret'),$secret))$error='Invalid setup secret.';
 elseif(!preg_match('/^[A-Za-z0-9_.-]{3,80}$/',$user))$error='Username must be 3–80 characters (letters, digits, dot, underscore, hyphen).';
 elseif(strlen($pass)<12)$error='Password must contain at least 12 characters.';
 else { db()->prepare('INSERT INTO admin_users(username,password_hash,active,created_at) VALUES(?,?,1,UTC_TIMESTAMP())')->execute([$user,password_hash($pass,PASSWORD_DEFAULT)]); audit('first_admin_created'); http_response_code(201); exit('Admin created. Delete setup-admin.php now, then sign in at admin-login.php.'); }
}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>First Admin Setup</title><link rel="stylesheet" href="assets/css/style.css"><link rel="stylesheet" href="assets/css/ultra.css"><script src="assets/js/particles.js" defer></script><main class="wrap" style="padding-top:8vh"><section class="panel main-card"><h1 style="font-size:34px;letter-spacing:-1px">First admin<span>.</span></h1><p class="sub" style="text-align:left">This page works only while no admin exists. Remove this file after setup.</p><?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif?><form method="post"><label>One-time setup secret<input name="setup_secret" type="password" required autocomplete="off"></label><label>Admin username<input name="username" required maxlength="80"></label><label>Strong password (12+ characters)<input name="password" type="password" required minlength="12" autocomplete="new-password"></label><button class="btn primary full">CREATE ADMIN</button></form></section></main><style>label{display:block;font-size:12px;margin:15px 0;color:#aab5d2}input{display:block;width:100%;margin-top:7px;padding:13px;border-radius:10px;border:1px solid #ffffff20;background:#080c1d;color:white}</style></html>
