<?php
// PRIVATE LIVE CONFIGURATION. Do not publish this file or ZIP.
return [
 'app_name' => 'SURAJ X XIT',
 'public_base_url' => 'https://surajteam.myvipsite.fun',
 'timezone' => 'Asia/Kolkata',
 'db_host' => 'localhost',
 'db_name' => 'ysvzvbtj_kuro',
 'db_user' => 'ysvzvbtj_kuro',
 'db_pass' => 'Surajpal1842',
 'ip_hash_salt' => 'kQ0MbxSvvMOZgwpOU8IRcx5-ymR1PuolX1Ax3wY7cGyYfQp3wEL_7YUrHeh1MuU0',
 'admin_setup_secret' => 'Mk2F-qy-Qdr14g28AkPqU1OAO8pVwFgekpo7uruqaFWODM66Eaua95Szz039NvRy',
 'shortener_api_url' => 'https://vplink.in/api',
 'shortener_api_token' => 'c96b87f01a26be8731712a777feb2ea7500b6a18',
 'shortener_destination_param' => 'url',
 'callback_secret' => 'udPv_sIfLpwvj1ESR-0w6sUgsD776LDZfJv3-yJLO-R7FOK5kri-brD3h24ZR4fZ',
 'allowed_origins' => ['https://surajteam.myvipsite.fun'],
 'trusted_proxies' => [],
 'key_lifetime_seconds' => 43200,
 'verification_lifetime_seconds' => 900,
 'rate_limit_per_minute' => 30,
 'secure_cookies' => true,
];
