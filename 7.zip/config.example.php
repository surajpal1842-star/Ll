<?php
// Copy to config.local.php; keep it outside public web access where possible.
// Do not put real credentials in Git or a public ZIP.
return [
 'app_name' => 'SURAJ X XIT',
 'public_base_url' => 'https://surajteam.myvipsite.fun',
 'timezone' => 'Asia/Kolkata',
 'db_host' => 'localhost', 'db_name' => 'CHANGE_ME', 'db_user' => 'CHANGE_ME', 'db_pass' => 'CHANGE_ME',
 'ip_hash_salt' => 'REPLACE_WITH_AT_LEAST_48_RANDOM_CHARACTERS',
 'admin_setup_secret' => 'REPLACE_WITH_A_ONE_TIME_RANDOM_SETUP_SECRET',
 'shortener_api_url' => 'https://vplink.in/api',
 'shortener_api_token' => '',
 'shortener_destination_param' => 'url',
 // Provider must call callback with token, ts, event_id, sig where
 // sig = HMAC-SHA256(token|ts|event_id, callback_secret). Only enable if provider supports it.
 'callback_secret' => '',
 'allowed_origins' => ['https://surajteam.myvipsite.fun'],
 'trusted_proxies' => [],
 'key_lifetime_seconds' => 43200,
 'verification_lifetime_seconds' => 900,
 'rate_limit_per_minute' => 30,
 'secure_cookies' => true,
];
