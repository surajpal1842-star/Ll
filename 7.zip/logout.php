<?php
require_once __DIR__.'/includes/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: admin-login.php');exit;}
if(admin_id()) audit('admin_logout',admin_id());
$_SESSION=[]; if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',$p['secure'],$p['httponly']);}
session_destroy(); header('Location: admin-login.php'); exit;
