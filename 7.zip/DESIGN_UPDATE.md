# SURAJ X XIT — NEBULA UI Refresh

This build replaces the previous visual design with a premium light glass interface, responsive admin workspace, refined license registry, redesigned GET KEY portal, refreshed admin sign-in, animated particle/connection background, reduced-motion support, hover transitions, and mobile navigation.

The existing PHP backend, MySQL schema, API actions, link-provider configuration, key generation/claim flow, device binding, audit events, revocation, admin authentication, CSRF protection, and rate limiting have been preserved. No Firebase dependency was added.

## Install
Upload the contents of `SURAJ_X_XIT/` to PHP hosting, follow `INSTALLATION.md`, configure the MySQL and short-link provider values, then remove `setup-admin.php` after creating the first administrator.

The UI has been syntax-checked alongside PHP files, but live database/provider behavior still requires configuration and testing on the target hosting.
