# SURAJ X XIT — License Key Portal

Mobile-first PHP 8+ / MySQL license portal. Public users do not need accounts. Admins authenticate separately.

## Included
- Premium responsive public GET KEY page and admin dashboard.
- MySQL schema, prepared statements, server-side key generation and HMAC key hashing.
- 12-hour default key validity; one active key per hashed IP; one-device binding on first key validation.
- Verification session expiry, signed callback validation, event replay prevention, rate limiting, admin sessions, CSRF, and audit logs.
- Configuration examples contain no real credentials.

## Important provider limitation
A short-link being opened is **not** proof that a verification task was completed. This project accepts completion only from a signed callback configured as `HMAC-SHA256(token|ts|event_id, callback_secret)`. The signed callback remains supported. A VPLINK browser-return compatibility route is included for the existing link-based flow, but browser referrers can be spoofed and are not cryptographic proof of task completion.

## Direct-use deployment
This private package includes `config.local.php` populated with the hosting/provider settings previously supplied and creates its tables on first request. Upload the contents into the configured domain document root, then open `get-key.php` or `admin-login.php`. See `START_HERE.txt`. Do not publish this ZIP because it contains credentials.

## API summary
- `GET api.php?action=health` / `connect`
- `POST api.php?action=request_key`
- `POST api.php?action=verification_status` with JSON `{ "token": "..." }`
- `POST api.php?action=claim_key` with JSON `{ "token": "..." }`
- `GET|POST api.php?action=shortener_callback` signed provider callback
- `POST api.php?action=key_status` or `verify_device` with JSON `{ "key": "...", "device_id": "stable-client-id" }`
- `POST api.php?action=admin_login` with JSON `{ "username": "...", "password": "...", "_csrf": "..." }`
- `POST api.php?action=admin_logout` with JSON `{ "_csrf": "..." }`
- `GET api.php?action=admin_stats`
- `GET api.php?action=admin_keys&q=&status=&page=`
- `POST api.php?action=admin_create_key` with JSON `{ "validity_seconds": 43200, "_csrf": "..." }`
- `POST api.php?action=admin_revoke_key` with JSON `{ "id": 123, "reason": "...", "_csrf": "..." }`
- `POST api.php?action=admin_change_password` with JSON `{ "old_password": "...", "new_password": "...", "_csrf": "..." }`

All admin API requests require an authenticated session and CSRF token. The admin page currently supports create, list/search/filter, revoke, stats, recent activity, and logout. Password change is available as an API action; configure a dedicated UI before handing the dashboard to nontechnical operators.

## Security notes
- The API trusts `REMOTE_ADDR` unless the immediate proxy IP is explicitly listed in `trusted_proxies`.
- The device identifier is supplied by the client and is not cryptographic hardware identity. Native clients should store a random installation ID securely and protect it against edits.
- One-IP-one-active-key can affect people sharing NAT/mobile carrier IPs.
- Key plaintext is only returned on initial issuance and is not recoverable from its hash. Admin-created keys are displayed once.
- `secure_cookies` must remain true on HTTPS production hosting.


## Global Admin Controls (Nebula build)
The authenticated admin dashboard includes **System controls** for maintenance mode, GET KEY on/off, app force-update policy, latest/minimum version, update URL, public announcement, and default key lifetime. Settings are stored in the `system_settings` table. Public API endpoint: `GET api.php?action=app_config`. Client integrations can pass `app_version` with key validation requests to receive `FORCE_UPDATE_REQUIRED` when the supplied version is below the configured minimum. A client that omits `app_version` cannot be force-update-gated; include it in your PHP/app API request.
