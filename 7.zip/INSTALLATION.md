# Installation — shared hosting / cPanel

## 1. Upload
Upload the project files to the HTTPS document root for `surajteam.myvipsite.fun`. Keep `config.local.php` out of public Git repositories. If possible place it one directory above `public_html` and update `includes/bootstrap.php` to read that private path. If it must remain in the web root, `.htaccess` denies HTTP access to it.

## 2. Create the database
In cPanel → MySQL Databases, create a database and a dedicated user. Grant that user only the privileges needed by this application. Open phpMyAdmin, select the new database, and import `database.sql`.

## 3. Configure secrets
Copy `config.local.php.example` to `config.local.php`. Set the database host/name/user/password, exact public HTTPS URL, and allowed origin. Generate independent random values for `ip_hash_salt`, `admin_setup_secret`, and `callback_secret` (each at least 48 random characters). Do not reuse passwords or commit the file. Keep `key_lifetime_seconds` at `43200` for 12 hours. Ensure PHP can make outbound HTTPS requests to the configured shortener API.

## 4. Create first admin
Visit `/setup-admin.php` over HTTPS. Enter the configured one-time setup secret, choose an admin username, and use a strong unique password of at least 12 characters. Once the page confirms success, **delete `setup-admin.php` immediately**. Then sign in at `/admin-login.php`. There is no public user login or registration.

## 5. Configure shortener verification
Configure the provider's URL-creation API settings and adapt the response parser in `includes/verification-service.php` if the response fields differ. Set the provider callback URL to:
`https://surajteam.myvipsite.fun/api.php?action=shortener_callback`

The provider must send `token`, Unix timestamp `ts`, unique `event_id`, and `sig`, where `sig` is lowercase hex HMAC-SHA256 of `token|ts|event_id` using `callback_secret`. This callback contract must be supported by your provider or a small trusted server-side adapter. Do not treat redirects, referers, or simply opening a link as verification. If the provider cannot sign callbacks, the end-to-end verification integration is not complete and claims should remain blocked.

## 6. Test
- `GET /api.php?action=health` should return JSON and status online.
- Open `/get-key.php`; the page must not require a public account.
- Request a key; confirm a real verification session is stored and the provider returns a short URL.
- Test valid signed callback, invalid signature, stale timestamp, and replayed event ID.
- Confirm pending sessions cannot claim; confirmed sessions can claim once.
- Confirm repeated claims do not mint another key (plaintext is not re-shown).
- Check a key expires at server-side issuance time + 12 hours.
- Check a second active key request from the same IP is rejected.
- Call `key_status` with a stable device ID twice; first request binds, same ID remains valid, different ID returns `DEVICE_MISMATCH`.
- Verify revoked and expired keys are rejected.
- Test admin login with correct and incorrect credentials, dashboard protection, CSRF failures, key creation/revocation, search/filter, and logout.
- Check PHP error logs and browser network requests for `Failed to fetch`, 500s, redirects, and malformed JSON.

## Troubleshooting
- `CONFIG_NOT_READY`: configuration values are missing or still example placeholders.
- `DATABASE_UNAVAILABLE`: check cPanel database name prefix, grants, hostname, and PHP PDO MySQL extension.
- `SHORTENER_NOT_CONFIGURED`: set the shortener URL/token and public base URL.
- `SHORTENER_UNAVAILABLE`: check outbound HTTPS/firewall and provider API status.
- `SHORTENER_BAD_RESPONSE`: update response parsing to match the provider's documented JSON.
- CORS: frontend and API should be served from the same HTTPS origin. Add only exact trusted origins to `allowed_origins`; never use `*` with credentials.
- If cPanel does not support PHP 8+, switch the domain to PHP 8.1+.

## Known live-test limitations
This source package cannot validate the owner's hosting credentials or the shortener provider's actual callback capability offline. Live database, DNS/HTTPS, provider API, and callback integration tests must be completed on the configured host before production use.
