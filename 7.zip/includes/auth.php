<?php
function admin_id(): ?int { return isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null; }
function require_admin(): int { $id=admin_id(); if (!$id) json_response(['success'=>false,'error'=>'AUTH_REQUIRED'],401); return $id; }
function verify_admin_password(string $username,string $password): ?array {
 $s=db()->prepare('SELECT id,username,password_hash FROM admin_users WHERE username=? AND active=1 LIMIT 1'); $s->execute([$username]); $u=$s->fetch();
 return $u && password_verify($password,$u['password_hash']) ? $u : null;
}
