<?php
function rate_limit(string $bucket, int $limit=30, int $window=60): void {
 $pdo=db(); $key=hash_hmac('sha256',$bucket.'|'.ip_hash(),(string)cfg('ip_hash_salt'));
 $pdo->beginTransaction();
 try {
  $s=$pdo->prepare('SELECT hits,window_started FROM rate_limits WHERE bucket_hash=? FOR UPDATE'); $s->execute([$key]); $r=$s->fetch();
  if (!$r) $pdo->prepare('INSERT INTO rate_limits(bucket_hash,hits,window_started) VALUES(?,1,UTC_TIMESTAMP())')->execute([$key]);
  else {
   $start=strtotime($r['window_started'].' UTC');
   if (time()-$start >= $window) $pdo->prepare('UPDATE rate_limits SET hits=1,window_started=UTC_TIMESTAMP() WHERE bucket_hash=?')->execute([$key]);
   elseif ((int)$r['hits'] >= $limit) { $pdo->rollBack(); json_response(['success'=>false,'error'=>'RATE_LIMITED'],429); }
   else $pdo->prepare('UPDATE rate_limits SET hits=hits+1 WHERE bucket_hash=?')->execute([$key]);
  }
  $pdo->commit();
 } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
}
