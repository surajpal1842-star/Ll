<?php
function json_response(array $data, int $status=200): never {
 http_response_code($status); header('Content-Type: application/json; charset=utf-8');
 header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
 echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE); exit;
}
function request_data(): array {
 $type=strtolower((string)($_SERVER['CONTENT_TYPE']??''));
 if (str_contains($type,'application/json')) { $raw=file_get_contents('php://input'); $v=json_decode($raw?:'',true); if (!is_array($v)) json_response(['success'=>false,'error'=>'INVALID_JSON'],400); return $v; }
 return $_POST;
}
function require_method(string ...$methods): void { if (!in_array($_SERVER['REQUEST_METHOD']??'GET',$methods,true)) { header('Allow: '.implode(', ',$methods)); json_response(['success'=>false,'error'=>'METHOD_NOT_ALLOWED'],405); } }
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
