<?php
function db(): PDO {
 static $pdo=null; if ($pdo instanceof PDO) return $pdo;
 foreach (['db_name','db_user','ip_hash_salt'] as $k) {
  $v=cfg($k); if (!$v || str_contains((string)$v,'CHANGE_ME') || str_contains((string)$v,'REPLACE_WITH')) throw new RuntimeException('CONFIG_NOT_READY');
 }
 $dsn='mysql:host='.cfg('db_host').';dbname='.cfg('db_name').';charset=utf8mb4';
 $pdo=new PDO($dsn,(string)cfg('db_user'),(string)cfg('db_pass'),[
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES=>false
 ]);
 // First-run installer: create the app's own tables automatically. Existing legacy tables are left untouched.
 $schemaFile=dirname(__DIR__).'/database.sql';
 if (is_file($schemaFile)) {
  $schema=(string)file_get_contents($schemaFile);
  foreach (preg_split('/;\s*(?:\r?\n|$)/', $schema) as $statement) {
   $statement=trim($statement);
   if ($statement!=='' && !str_starts_with($statement,'--')) $pdo->exec($statement);
  }
 }
 // Seed the admin only when the username does not exist; never overwrite an existing password.
 $s=$pdo->prepare('SELECT id FROM admin_users WHERE username=? LIMIT 1'); $s->execute(['admin']);
 if (!$s->fetch()) {
  $hash='$2y$12$WANmbrNKc8xSqciaMQSYr.lbPebUysi2bWjRF1iLHl.MiEo5df/aW';
  $pdo->prepare('INSERT INTO admin_users(username,password_hash,active,created_at) VALUES(?,?,1,UTC_TIMESTAMP())')->execute(['admin',$hash]);
 }
 return $pdo;
}
