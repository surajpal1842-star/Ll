<?php
function new_license_key(): string { return 'SURJ-'.strtoupper(bin2hex(random_bytes(2))).'-'.strtoupper(bin2hex(random_bytes(2))).'-'.strtoupper(bin2hex(random_bytes(2))); }
function key_hash(string $key): string { return hash_hmac('sha256',$key,(string)cfg('ip_hash_salt')); }
function issue_key(PDO $pdo, ?int $sessionId, string $ipH, int $ttl=43200, ?int $adminId=null): array {
 $pdo->beginTransaction();
 try {
  if ($sessionId !== null) {
   $s=$pdo->prepare('SELECT * FROM verification_sessions WHERE id=? FOR UPDATE'); $s->execute([$sessionId]); $vs=$s->fetch();
   if (!$vs || $vs['status']!=='verified' || $vs['expires_at']<=gmdate('Y-m-d H:i:s')) throw new DomainException('VERIFICATION_REQUIRED');
   if ($vs['claimed_at']!==null && $vs['issued_key_id']) {
    $q=$pdo->prepare('SELECT key_prefix,expires_at FROM license_keys WHERE id=?'); $q->execute([$vs['issued_key_id']]); $k=$q->fetch();
    if ($k) { $pdo->commit(); return ['already_claimed'=>true,'key'=>null,'expires_at'=>$k['expires_at'],'key_prefix'=>$k['key_prefix']]; }
   }
  }
  // Public GET KEY claims are limited to one active key per IP; admins may issue multiple independent keys.
  if ($sessionId !== null) { $s=$pdo->prepare("SELECT id FROM license_keys WHERE ip_hash=? AND status='active' AND expires_at>UTC_TIMESTAMP() LIMIT 1 FOR UPDATE"); $s->execute([$ipH]); if ($s->fetch()) throw new DomainException('ACTIVE_KEY_EXISTS'); }
  $plain=new_license_key(); $hash=key_hash($plain); $expires=gmdate('Y-m-d H:i:s',time()+$ttl);
  $s=$pdo->prepare("INSERT INTO license_keys(key_hash,key_prefix,status,created_at,expires_at,ip_hash,verification_session_id,issued_by_admin_id) VALUES(?,?,'active',UTC_TIMESTAMP(),?,?,?,?)");
  $s->execute([$hash,substr($plain,0,9),$expires,$ipH,$sessionId,$adminId]); $keyId=(int)$pdo->lastInsertId();
  if ($sessionId!==null) $pdo->prepare("UPDATE verification_sessions SET status='claimed',claimed_at=UTC_TIMESTAMP(),issued_key_id=? WHERE id=?")->execute([$keyId,$sessionId]);
  audit('key_issued',$adminId,['key_id'=>$keyId,'source'=>$sessionId===null?'admin':'public']);
  $pdo->commit(); return ['already_claimed'=>false,'key'=>$plain,'expires_at'=>$expires,'remaining_seconds'=>$ttl,'key_prefix'=>substr($plain,0,9)];
 } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
}
