<?php
declare(strict_types=1);
date_default_timezone_set('UTC');
$configFile = dirname(__DIR__) . '/config.local.php';
$config = is_file($configFile) ? require $configFile : [];
if (!is_array($config)) $config = [];
$defaults = [
 'app_name'=>'SURAJ X XIT','public_base_url'=>'','timezone'=>'UTC',
 'db_host'=>'localhost','db_name'=>'CHANGE_ME','db_user'=>'CHANGE_ME','db_pass'=>'',
 'ip_hash_salt'=>'','admin_setup_secret'=>'','shortener_api_url'=>'https://vplink.in/api',
 'shortener_api_token'=>'','shortener_destination_param'=>'url','callback_secret'=>'',
 'allowed_origins'=>[],'trusted_proxies'=>[],'key_lifetime_seconds'=>43200,
 'verification_lifetime_seconds'=>900,'rate_limit_per_minute'=>30,'secure_cookies'=>true
];
$config = array_merge($defaults, $config);
date_default_timezone_set((string)$config['timezone']);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('sxxit_admin');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>(bool)$config['secure_cookies'],'httponly'=>true,'samesite'=>'Strict']);
    session_start();
}
require_once __DIR__.'/response.php';
require_once __DIR__.'/database.php';
require_once __DIR__.'/auth.php';
require_once __DIR__.'/csrf.php';
require_once __DIR__.'/rate-limit.php';
function cfg(string $key) { global $config; return $config[$key] ?? null; }
function client_ip(): string {
    // REMOTE_ADDR is authoritative unless a proxy is explicitly trusted.
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!filter_var($remote, FILTER_VALIDATE_IP)) return '0.0.0.0';
    $trusted = cfg('trusted_proxies');
    if (is_array($trusted) && in_array($remote, $trusted, true)) {
        $forwarded = trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''))[0]);
        if (filter_var($forwarded, FILTER_VALIDATE_IP)) return $forwarded;
    }
    return $remote;
}
function ip_hash(): string { return hash_hmac('sha256', client_ip(), (string)cfg('ip_hash_salt')); }
function audit(string $event, ?int $adminId=null, array $details=[]): void {
    try { db()->prepare('INSERT INTO audit_logs(event_name,admin_user_id,ip_hash,details_json,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')
        ->execute([$event,$adminId,ip_hash(),json_encode($details,JSON_UNESCAPED_SLASHES)]); } catch(Throwable $e) { error_log('audit log write failed'); }
}
