<?php
function create_verification(): array {
 $pdo=db();
 if (!cfg('shortener_api_token') || !cfg('public_base_url') || !cfg('shortener_api_url')) throw new RuntimeException('SHORTENER_NOT_CONFIGURED');
 $token=bin2hex(random_bytes(32));
 $expires=gmdate('Y-m-d H:i:s',time()+(int)cfg('verification_lifetime_seconds'));
 $s=$pdo->prepare("INSERT INTO verification_sessions(token_hash,status,ip_hash,created_at,expires_at) VALUES(?,'pending',?,UTC_TIMESTAMP(),?)");
 $s->execute([hash('sha256',$token),ip_hash(),$expires]); $id=(int)$pdo->lastInsertId();
 $callback=rtrim((string)cfg('public_base_url'),'/').'/api.php?action=shortener_return&token='.rawurlencode($token);
 // VPLINK legacy API contract: GET endpoint with api=<token>&url=<destination>.
 $url=(string)cfg('shortener_api_url');
 $params=['url'=>$callback,'api'=>(string)cfg('shortener_api_token'),'format'=>'json'];
 $url.=(str_contains($url,'?')?'&':'?').http_build_query($params,'','&',PHP_QUERY_RFC3986);
 $body=false; $status=0; $contentType='';
 if (function_exists('curl_init')) {
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,CURLOPT_HTTPHEADER=>['Accept: application/json, text/plain;q=0.9'],CURLOPT_USERAGENT=>'SURAJ-X-XIT-License-Portal/2.0']);
  $body=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $contentType=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE); $curlErr=curl_error($ch); curl_close($ch);
  if ($body===false) { error_log('VPLINK transport failure: '.$curlErr); throw new RuntimeException('SHORTENER_NETWORK_ERROR'); }
 } else {
  $ctx=stream_context_create(['http'=>['timeout'=>12,'ignore_errors'=>true,'follow_location'=>0,'header'=>"Accept: application/json, text/plain;q=0.9\r\nUser-Agent: SURAJ-X-XIT-License-Portal/2.0\r\n"]]);
  $body=@file_get_contents($url,false,$ctx);
  foreach (($http_response_header??[]) as $h) { if (preg_match('/^HTTP\/\S+\s+(\d+)/i',$h,$m)) $status=(int)$m[1]; if (stripos($h,'Content-Type:')===0) $contentType=trim(substr($h,13)); }
  if ($body===false) throw new RuntimeException('SHORTENER_NETWORK_ERROR');
 }
 $j=json_decode((string)$body,true);
 if ($status===401 || $status===403 || (is_array($j) && (($j['status']??'')==='error') && preg_match('/token|api key|credential|authori[sz]/i',(string)($j['message']??'')))) {
  error_log('VPLINK rejected API credentials or endpoint configuration; HTTP '.$status.'; response '.substr((string)$body,0,400));
  throw new RuntimeException('SHORTENER_AUTH_FAILED');
 }
 if ($status===429) throw new RuntimeException('SHORTENER_RATE_LIMITED');
 if ($status>=500) { error_log('VPLINK upstream error HTTP '.$status.': '.substr((string)$body,0,400)); throw new RuntimeException('SHORTENER_UPSTREAM_ERROR'); }
 $short=is_array($j)?($j['shortenedUrl']??$j['short_url']??$j['shortened_url']??$j['url']??$j['data']['url']??null):null;
 if (!$short && is_string($body) && filter_var(trim($body),FILTER_VALIDATE_URL)) $short=trim($body);
 if (is_array($j) && (($j['status']??'')==='error')) { error_log('VPLINK API error: '.substr((string)($j['message']??'unspecified'),0,400)); throw new RuntimeException('SHORTENER_API_REJECTED'); }
 if ($status<200 || $status>=300 || !is_string($short) || !filter_var($short,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($short,PHP_URL_SCHEME)),['http','https'],true)) {
  error_log('VPLINK invalid response; HTTP '.$status.'; content-type '.$contentType.'; body '.substr((string)$body,0,400));
  throw new RuntimeException('SHORTENER_BAD_RESPONSE');
 }
 $pdo->prepare("UPDATE verification_sessions SET short_url=? WHERE id=?")->execute([$short,$id]);
 return ['token'=>$token,'verification_url'=>$short,'expires_in'=>(int)cfg('verification_lifetime_seconds')];
}

function verify_callback(array $d): void {
 $token=(string)($d['token']??''); $ts=(string)($d['ts']??''); $event=(string)($d['event_id']??''); $sig=(string)($d['sig']??'');
 if(!preg_match('/^[a-f0-9]{64}$/',$token)||!ctype_digit($ts)||$event===''||strlen($event)>190||abs(time()-(int)$ts)>300) json_response(['success'=>false,'error'=>'INVALID_CALLBACK'],403);
 $secret=(string)cfg('callback_secret'); if($secret==='') json_response(['success'=>false,'error'=>'SIGNED_CALLBACK_NOT_CONFIGURED'],503);
 $expected=hash_hmac('sha256',$token.'|'.$ts.'|'.$event,$secret);
 if(!hash_equals($expected,$sig)) json_response(['success'=>false,'error'=>'INVALID_CALLBACK_SIGNATURE'],403);
 $pdo=db(); $pdo->beginTransaction();
 try {
  $s=$pdo->prepare('SELECT id,status,ip_hash,expires_at FROM verification_sessions WHERE token_hash=? FOR UPDATE'); $s->execute([hash('sha256',$token)]); $r=$s->fetch();
  if(!$r||$r['status']!=='pending'||$r['expires_at']<=gmdate('Y-m-d H:i:s')) { $pdo->rollBack(); json_response(['success'=>false,'error'=>'SESSION_INVALID_OR_EXPIRED'],410); }
  $pdo->prepare('INSERT INTO callback_events(event_id,received_at) VALUES(?,UTC_TIMESTAMP())')->execute([$event]);
  $pdo->prepare("UPDATE verification_sessions SET status='verified',verified_at=UTC_TIMESTAMP(),provider_event_id=? WHERE id=?")->execute([$event,$r['id']]);
  $pdo->commit(); audit('verification_confirmed',null,['session_id'=>(int)$r['id']]); json_response(['success'=>true,'status'=>'verified']);
 } catch(PDOException $e) { if($pdo->inTransaction())$pdo->rollBack(); if((string)$e->getCode()==='23000') json_response(['success'=>false,'error'=>'REPLAYED_EVENT'],409); error_log('callback database error'); json_response(['success'=>false,'error'=>'CALLBACK_PROCESSING_FAILED'],500); }
}
