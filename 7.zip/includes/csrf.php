<?php
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function require_csrf(?array $data=null): void {
 $data=$data??request_data(); $sent=(string)($data['_csrf']??($_SERVER['HTTP_X_CSRF_TOKEN']??''));
 if (empty($_SESSION['csrf']) || !hash_equals((string)$_SESSION['csrf'],$sent)) json_response(['success'=>false,'error'=>'CSRF_FAILED'],403);
}
