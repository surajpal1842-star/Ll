# API reference

All responses are JSON except the public HTML pages. POST bodies should use `Content-Type: application/json`.

| Action | Method | Authentication | Purpose |
|---|---|---|---|
| `health`, `connect` | GET | Public | Safe service/database health |
| `request_key` | POST | Public + rate limit | Create verification session and request short URL |
| `verification_status` | POST | Public + session IP binding | Poll session status |
| `claim_key` | POST | Public + verified session | Issue one 12-hour key |
| `shortener_callback` | GET/POST | Signed callback | Confirm provider completion |
| `key_status`, `verify_device` | POST | License key + device ID | Validate key and atomically bind first device |
| `admin_login` | POST | CSRF + rate limit | Establish admin session |
| `admin_logout` | POST | Admin session + CSRF | Invalidate admin session |
| `admin_stats` | GET | Admin session | Dashboard stats and audit events |
| `admin_keys` | GET | Admin session | Search/filter key metadata |
| `admin_create_key` | POST | Admin session + CSRF | Manually issue key |
| `admin_revoke_key` | POST | Admin session + CSRF | Revoke by database record ID |
| `admin_change_password` | POST | Admin session + CSRF | Change own password |

### Error format
`{"success":false,"error":"STABLE_ERROR_CODE"}`. The API avoids returning exception messages, SQL details, or secret configuration.

### Callback signature
`sig = lowercase_hex(HMAC_SHA256(token + "|" + ts + "|" + event_id, callback_secret))`.
`ts` is Unix seconds and must be within five minutes. `event_id` must be unique. Provider support for this contract is required for reliable verification.
