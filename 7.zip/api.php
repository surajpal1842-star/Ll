<?php
declare(strict_types=1);
require_once __DIR__.'/includes/bootstrap.php';
header('Vary: Origin');
$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
if($origin!=='') {
 $allowed=cfg('allowed_origins');
 if(is_array($allowed)&&in_array($origin,$allowed,true)) header('Access-Control-Allow-Origin: '.$origin);
 else json_response(['success'=>false,'error'=>'ORIGIN_NOT_ALLOWED'],403);
 header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
 header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
}
if(($_SERVER['REQUEST_METHOD']??'')==='OPTIONS') { http_response_code(204); exit; }
$action=(string)($_GET['action']??$_POST['action']??'');
function sx_defaults(): array { return ['maintenance_enabled'=>'0','maintenance_message'=>'System maintenance is in progress. Please try again shortly.','force_update_enabled'=>'0','latest_version'=>'1.0.0','minimum_version'=>'1.0.0','update_url'=>'','announcement'=>'','get_key_enabled'=>'1','default_key_seconds'=>(string)cfg('key_lifetime_seconds')]; }
function sx_settings(PDO $pdo): array { $out=sx_defaults(); $rows=$pdo->query('SELECT setting_key,setting_value FROM system_settings')->fetchAll(); foreach($rows as $r) if(array_key_exists($r['setting_key'],$out)) $out[$r['setting_key']]=$r['setting_value']; return $out; }
function sx_save_settings(PDO $pdo,array $values): void { $st=$pdo->prepare('INSERT INTO system_settings(setting_key,setting_value,updated_at) VALUES(?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)'); foreach($values as $k=>$v) $st->execute([$k,(string)$v]); }
function sx_version_block(array $settings,array $data): void { if($settings['force_update_enabled']==='1') { $v=trim((string)($data['app_version']??'')); if($v==='' || version_compare($v,$settings['minimum_version'],'<')) json_response(['success'=>false,'error'=>'FORCE_UPDATE_REQUIRED','minimum_version'=>$settings['minimum_version'],'latest_version'=>$settings['latest_version'],'update_url'=>$settings['update_url']],426); } }
try {
 if($action==='health'||$action==='connect') {
  require_method('GET');
  try { db()->query('SELECT 1'); json_response(['success'=>true,'service'=>cfg('app_name'),'status'=>'online']); }
  catch(Throwable $e) { json_response(['success'=>false,'service'=>cfg('app_name'),'status'=>'degraded','error'=>'DATABASE_UNAVAILABLE'],503); }
 }
 $pdo=db();
 if($action==='app_config') { require_method('GET'); $z=sx_settings($pdo); json_response(['success'=>true,'app_name'=>cfg('app_name'),'maintenance_enabled'=>$z['maintenance_enabled']==='1','maintenance_message'=>$z['maintenance_message'],'force_update_enabled'=>$z['force_update_enabled']==='1','latest_version'=>$z['latest_version'],'minimum_version'=>$z['minimum_version'],'update_url'=>$z['update_url'],'announcement'=>$z['announcement'],'get_key_enabled'=>$z['get_key_enabled']==='1','default_key_seconds'=>(int)$z['default_key_seconds']]); }
 if($action==='shortener_callback') { require_method('GET','POST'); $d=$_SERVER['REQUEST_METHOD']==='POST'?request_data():$_GET; verify_callback($d); }
 if($action==='shortener_return') {
  require_method('GET');
  $token=(string)($_GET['token']??'');
  if(!preg_match('/^[a-f0-9]{64}$/',$token)) json_response(['success'=>false,'error'=>'INVALID_TOKEN'],403);
  $ref=(string)($_SERVER['HTTP_REFERER']??''); $host=strtolower((string)parse_url($ref,PHP_URL_HOST));
  if(!in_array($host,['vplink.in','www.vplink.in','vplinks.in','www.vplinks.in'],true)) json_response(['success'=>false,'error'=>'SHORTENER_REFERRER_REQUIRED'],403);
  $s=$pdo->prepare("SELECT id,status,ip_hash,expires_at FROM verification_sessions WHERE token_hash=? LIMIT 1"); $s->execute([hash('sha256',$token)]); $r=$s->fetch();
  if(!$r||$r['status']!=='pending'||$r['expires_at']<=gmdate('Y-m-d H:i:s')||!hash_equals((string)$r['ip_hash'],ip_hash())) json_response(['success'=>false,'error'=>'SESSION_INVALID_OR_EXPIRED'],410);
  $u=$pdo->prepare("UPDATE verification_sessions SET status='verified',verified_at=UTC_TIMESTAMP() WHERE id=? AND status='pending'"); $u->execute([$r['id']]);
  if($u->rowCount()!==1) json_response(['success'=>false,'error'=>'SESSION_ALREADY_USED'],409);
  audit('verification_confirmed',null,['session_id'=>(int)$r['id'],'method'=>'provider_return']);
  header('Location: '.rtrim((string)cfg('public_base_url'),'/').'/get-key.php?verified=1',true,302); exit;
 }
 if($action==='request_key') {
  require_method('POST'); $settings=sx_settings($pdo); if($settings['maintenance_enabled']==='1') json_response(['success'=>false,'error'=>'MAINTENANCE_MODE','message'=>$settings['maintenance_message']],503); if($settings['get_key_enabled']!=='1') json_response(['success'=>false,'error'=>'GET_KEY_DISABLED'],503); rate_limit('request_key',(int)cfg('rate_limit_per_minute'));
  $active=$pdo->prepare("SELECT id FROM license_keys WHERE ip_hash=? AND status='active' AND expires_at>UTC_TIMESTAMP() LIMIT 1"); $active->execute([ip_hash()]);
  if($active->fetch()) json_response(['success'=>false,'error'=>'ACTIVE_KEY_EXISTS'],409);
  try { $r=create_verification(); audit('verification_requested',null,[]); json_response(['success'=>true,'status'=>'pending']+$r); }
  catch(Throwable $e) { $code=$e->getMessage(); error_log('verification request failed: '.$code); $allowed=['SHORTENER_NOT_CONFIGURED','SHORTENER_NETWORK_ERROR','SHORTENER_AUTH_FAILED','SHORTENER_RATE_LIMITED','SHORTENER_UPSTREAM_ERROR','SHORTENER_API_REJECTED','SHORTENER_BAD_RESPONSE']; if(!in_array($code,$allowed,true)) $code='SHORTENER_UNAVAILABLE'; json_response(['success'=>false,'error'=>$code],503); }
 }
 if($action==='verification_status') {
  require_method('POST'); rate_limit('verification_status',60);
  $d=request_data(); $token=(string)($d['token']??'');
  if(!preg_match('/^[a-f0-9]{64}$/',$token)) json_response(['success'=>false,'error'=>'INVALID_TOKEN'],400);
  $s=$pdo->prepare('SELECT status,expires_at FROM verification_sessions WHERE token_hash=? AND ip_hash=?'); $s->execute([hash('sha256',$token),ip_hash()]); $r=$s->fetch();
  if(!$r) json_response(['success'=>false,'error'=>'SESSION_NOT_FOUND'],404);
  if($r['expires_at']<=gmdate('Y-m-d H:i:s') && $r['status']==='pending') { $pdo->prepare("UPDATE verification_sessions SET status='expired' WHERE token_hash=?")->execute([hash('sha256',$token)]); $r['status']='expired'; }
  json_response(['success'=>true,'status'=>$r['status'],'expires_at'=>$r['expires_at']]);
 }
 if($action==='claim_key') {
  require_method('POST'); $settings=sx_settings($pdo); if($settings['maintenance_enabled']==='1') json_response(['success'=>false,'error'=>'MAINTENANCE_MODE','message'=>$settings['maintenance_message']],503); rate_limit('claim_key',30); $d=request_data(); $token=(string)($d['token']??'');
  if(!preg_match('/^[a-f0-9]{64}$/',$token)) json_response(['success'=>false,'error'=>'INVALID_TOKEN'],400);
  $s=$pdo->prepare('SELECT id,status,ip_hash FROM verification_sessions WHERE token_hash=?'); $s->execute([hash('sha256',$token)]); $r=$s->fetch();
  if(!$r||!hash_equals($r['ip_hash'],ip_hash())) json_response(['success'=>false,'error'=>'SESSION_NOT_FOUND'],403);
  if($r['status']==='claimed') json_response(['success'=>false,'error'=>'KEY_ALREADY_CLAIMED','message'=>'The key was already issued. The plaintext key is shown only once.'],409);
  try { $issued=issue_key($pdo,(int)$r['id'],ip_hash(),max(300,min(2592000,(int)$settings['default_key_seconds']))); if(empty($issued['key'])) json_response(['success'=>false,'error'=>'KEY_ALREADY_CLAIMED'],409); json_response(['success'=>true,'status'=>'claimed','key'=>$issued['key'],'expires_at'=>$issued['expires_at'],'remaining_seconds'=>$issued['remaining_seconds']]); }
  catch(DomainException $e) { json_response(['success'=>false,'error'=>$e->getMessage()],409); }
 }
 if($action==='key_status'||$action==='verify_device') {
  require_method('POST'); rate_limit('key_status',30); $d=request_data(); $settings=sx_settings($pdo); if($settings['maintenance_enabled']==='1') json_response(['success'=>false,'valid'=>false,'error'=>'MAINTENANCE_MODE','message'=>$settings['maintenance_message']],503); sx_version_block($settings,$d); $key=trim((string)($d['key']??'')); $device=trim((string)($d['device_id']??''));
  if($key===''||!preg_match('/^SURJ-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$/',$key)) json_response(['success'=>false,'valid'=>false,'error'=>'INVALID_KEY'],400);
  $pdo->beginTransaction();
  try {
   $s=$pdo->prepare('SELECT * FROM license_keys WHERE key_hash=? FOR UPDATE'); $s->execute([key_hash($key)]); $r=$s->fetch();
   if(!$r) { $pdo->commit(); json_response(['success'=>true,'valid'=>false,'error'=>'INVALID_KEY']); }
   if($r['status']==='revoked') { $pdo->commit(); json_response(['success'=>true,'valid'=>false,'error'=>'REVOKED_KEY']); }
   if($r['expires_at']<=gmdate('Y-m-d H:i:s')) { $pdo->prepare("UPDATE license_keys SET status='expired' WHERE id=? AND status='active'")->execute([$r['id']]); $pdo->commit(); json_response(['success'=>true,'valid'=>false,'error'=>'EXPIRED_KEY']); }
   if(!preg_match('/^[A-Za-z0-9._:-]{16,190}$/',$device)) { $pdo->rollBack(); json_response(['success'=>false,'error'=>'INVALID_DEVICE_ID'],400); }
   $dh=hash_hmac('sha256',$device,(string)cfg('ip_hash_salt'));
   if($r['device_hash']===null) $pdo->prepare('UPDATE license_keys SET device_hash=?,first_used_at=COALESCE(first_used_at,UTC_TIMESTAMP()),last_used_at=UTC_TIMESTAMP() WHERE id=? AND device_hash IS NULL')->execute([$dh,$r['id']]);
   elseif(!hash_equals($r['device_hash'],$dh)) { $pdo->commit(); json_response(['success'=>true,'valid'=>false,'error'=>'DEVICE_MISMATCH']); }
   else $pdo->prepare('UPDATE license_keys SET last_used_at=UTC_TIMESTAMP() WHERE id=?')->execute([$r['id']]);
   $pdo->commit(); json_response(['success'=>true,'valid'=>true,'status'=>'active','expires_at'=>$r['expires_at'],'device_bound'=>true]);
  } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); error_log('key validation failed'); json_response(['success'=>false,'error'=>'INTERNAL_ERROR'],500); }
 }
 if($action==='admin_login') {
  require_method('POST'); rate_limit('admin_login',8,300); $d=request_data(); require_csrf($d);
  $u=(string)($d['username']??''); $p=(string)($d['password']??''); $user=verify_admin_password($u,$p);
  if(!$user) { audit('admin_login_failed'); json_response(['success'=>false,'error'=>'INVALID_CREDENTIALS'],401); }
  session_regenerate_id(true); $_SESSION['admin_id']=(int)$user['id']; $_SESSION['csrf']=bin2hex(random_bytes(32));
  $pdo->prepare('UPDATE admin_users SET last_login_at=UTC_TIMESTAMP() WHERE id=?')->execute([$user['id']]); audit('admin_login',(int)$user['id']);
  json_response(['success'=>true,'csrf'=>csrf_token()]);
 }
 if($action==='admin_logout') { require_method('POST'); $id=require_admin(); $d=request_data(); require_csrf($d); audit('admin_logout',$id); $_SESSION=[]; session_destroy(); json_response(['success'=>true]); }
 if(str_starts_with($action,'admin_')) {
  $id=require_admin(); if($_SERVER['REQUEST_METHOD']==='POST') { $d=request_data(); require_csrf($d); } else $d=[];
  if($action==='admin_stats') {
   require_method('GET'); $stats=$pdo->query("SELECT COUNT(*) total, SUM(status='active' AND expires_at>UTC_TIMESTAMP()) active, SUM(status='expired' OR (status='active' AND expires_at<=UTC_TIMESTAMP())) expired, SUM(status='revoked') revoked, SUM(device_hash IS NOT NULL) bound, SUM(device_hash IS NULL) unbound, SUM(DATE(created_at)=UTC_DATE()) today FROM license_keys")->fetch();
   $recent=$pdo->query('SELECT id,event_name,created_at FROM audit_logs ORDER BY id DESC LIMIT 12')->fetchAll(); json_response(['success'=>true,'stats'=>$stats,'recent'=>$recent,'csrf'=>csrf_token()]);
  }
  if($action==='admin_create_key') { require_method('POST'); $settings=sx_settings($pdo); $ttl=max(300,min(2592000,(int)($d['validity_seconds']??$settings['default_key_seconds']))); try { $r=issue_key($pdo,null,ip_hash(),$ttl,$id); json_response(['success'=>true,'key'=>$r['key'],'expires_at'=>$r['expires_at']]); } catch(DomainException $e) { json_response(['success'=>false,'error'=>$e->getMessage()],409); } }
  if($action==='admin_revoke_key') {
   require_method('POST'); $keyId=(int)($d['id']??0); $reason=substr(trim((string)($d['reason']??'Admin revoked')),0,255);
   $s=$pdo->prepare("UPDATE license_keys SET status='revoked',revoked_at=UTC_TIMESTAMP(),revocation_reason=? WHERE id=? AND status='active'"); $s->execute([$reason,$keyId]);
   audit('key_revoked',$id,['affected'=>$s->rowCount()]); json_response(['success'=>$s->rowCount()===1,'error'=>$s->rowCount()===1?null:'KEY_NOT_ACTIVE']);
  }
  if($action==='admin_keys') {
   require_method('GET'); $q=substr(trim((string)($_GET['q']??'')),0,50); $status=(string)($_GET['status']??'all'); $page=max(1,(int)($_GET['page']??1));
   $where=[];$args=[]; if($q!==''){$where[]='key_prefix LIKE ?';$args[]='%'.$q.'%';} if(in_array($status,['active','revoked','expired'],true)){$where[]='status=?';$args[]=$status;}
   $sql='SELECT id,key_prefix,CASE WHEN status=\'active\' AND expires_at<=UTC_TIMESTAMP() THEN \'expired\' ELSE status END AS status,created_at,expires_at,first_used_at,last_used_at,device_hash IS NOT NULL AS bound,revocation_reason FROM license_keys'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY id DESC LIMIT 50 OFFSET '.(($page-1)*50);
   $s=$pdo->prepare($sql);$s->execute($args);json_response(['success'=>true,'keys'=>$s->fetchAll(),'page'=>$page]);
  }
  if($action==='admin_settings') { require_method('GET'); json_response(['success'=>true,'settings'=>sx_settings($pdo),'csrf'=>csrf_token()]); }
  if($action==='admin_save_settings') { require_method('POST'); $v=$d['settings']??[]; if(!is_array($v)) json_response(['success'=>false,'error'=>'INVALID_SETTINGS'],400); $old=sx_settings($pdo); $allowed=['maintenance_enabled','maintenance_message','force_update_enabled','latest_version','minimum_version','update_url','announcement','get_key_enabled','default_key_seconds']; $n=[]; foreach($allowed as $k) $n[$k]=isset($v[$k])?(string)$v[$k]:$old[$k]; foreach(['maintenance_enabled','force_update_enabled','get_key_enabled'] as $k) $n[$k]=in_array($n[$k],['1','true','on'],true)?'1':'0'; $n['maintenance_message']=substr(trim($n['maintenance_message']),0,500); $n['announcement']=substr(trim($n['announcement']),0,1000); foreach(['latest_version','minimum_version'] as $k) if(!preg_match('/^[0-9]+(?:\.[0-9]+){0,3}$/',$n[$k])) json_response(['success'=>false,'error'=>'INVALID_VERSION','field'=>$k],400); $n['update_url']=trim($n['update_url']); if($n['update_url']!=='' && (!filter_var($n['update_url'],FILTER_VALIDATE_URL)||!in_array(strtolower((string)parse_url($n['update_url'],PHP_URL_SCHEME)),['https','http'],true))) json_response(['success'=>false,'error'=>'INVALID_UPDATE_URL'],400); if(!ctype_digit($n['default_key_seconds']) || (int)$n['default_key_seconds']<300 || (int)$n['default_key_seconds']>2592000) json_response(['success'=>false,'error'=>'INVALID_KEY_DURATION'],400); sx_save_settings($pdo,$n); audit('admin_settings_updated',$id,['maintenance'=>$n['maintenance_enabled'],'force_update'=>$n['force_update_enabled'],'get_key_enabled'=>$n['get_key_enabled']]); json_response(['success'=>true,'settings'=>$n]); }
  if($action==='admin_change_password') { require_method('POST'); $old=(string)($d['old_password']??'');$new=(string)($d['new_password']??''); if(strlen($new)<12)json_response(['success'=>false,'error'=>'PASSWORD_TOO_SHORT'],400);$s=$pdo->prepare('SELECT password_hash FROM admin_users WHERE id=?');$s->execute([$id]);if(!password_verify($old,(string)$s->fetchColumn()))json_response(['success'=>false,'error'=>'INVALID_CREDENTIALS'],401);$pdo->prepare('UPDATE admin_users SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$id]);audit('admin_password_changed',$id);json_response(['success'=>true]); }
 }
 json_response(['success'=>false,'error'=>'UNKNOWN_ACTION'],404);
} catch(Throwable $e) {
 error_log('SURAJ X XIT API error: '.$e->getMessage());
 json_response(['success'=>false,'error'=>$e->getMessage()==='CONFIG_NOT_READY'?'CONFIG_NOT_READY':'INTERNAL_ERROR'],503);
}
