SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS admin_users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL, active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL, last_login_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS verification_sessions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, token_hash CHAR(64) NOT NULL UNIQUE,
 status ENUM('pending','verified','claimed','expired','rejected') NOT NULL DEFAULT 'pending',
 ip_hash CHAR(64) NOT NULL, short_url VARCHAR(2048) NULL, created_at DATETIME NOT NULL,
 expires_at DATETIME NOT NULL, verified_at DATETIME NULL, claimed_at DATETIME NULL,
 provider_event_id VARCHAR(190) NULL UNIQUE, issued_key_id BIGINT UNSIGNED NULL,
 KEY idx_verification_status_expiry(status,expires_at), KEY idx_verification_ip(ip_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS license_keys (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, key_hash CHAR(64) NOT NULL UNIQUE,
 key_prefix VARCHAR(16) NOT NULL, status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',
 created_at DATETIME NOT NULL, expires_at DATETIME NOT NULL, first_used_at DATETIME NULL,
 last_used_at DATETIME NULL, device_hash CHAR(64) NULL, ip_hash CHAR(64) NOT NULL,
 verification_session_id BIGINT UNSIGNED NULL, issued_by_admin_id BIGINT UNSIGNED NULL,
 revoked_at DATETIME NULL, revocation_reason VARCHAR(255) NULL,
 KEY idx_keys_status_expiry(status,expires_at), KEY idx_keys_ip(ip_hash), KEY idx_keys_created(created_at),
 CONSTRAINT fk_key_verification FOREIGN KEY(verification_session_id) REFERENCES verification_sessions(id) ON DELETE SET NULL,
 CONSTRAINT fk_key_admin FOREIGN KEY(issued_by_admin_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS callback_events (
 event_id VARCHAR(190) PRIMARY KEY, received_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_name VARCHAR(100) NOT NULL,
 admin_user_id BIGINT UNSIGNED NULL, ip_hash CHAR(64) NOT NULL, details_json JSON NULL,
 created_at DATETIME NOT NULL, KEY idx_audit_created(created_at), KEY idx_audit_event(event_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS rate_limits (
 bucket_hash CHAR(64) PRIMARY KEY, hits INT UNSIGNED NOT NULL, window_started DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_settings (
 setting_key VARCHAR(100) PRIMARY KEY, setting_value TEXT NOT NULL, updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
